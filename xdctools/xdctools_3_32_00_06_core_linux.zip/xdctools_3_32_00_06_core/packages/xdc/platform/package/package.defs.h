/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xdc_platform__
#define xdc_platform__



#endif /* xdc_platform__ */ 
