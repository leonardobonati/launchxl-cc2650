/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A46
 */

#ifndef xdc_rov_dss__
#define xdc_rov_dss__



#endif /* xdc_rov_dss__ */ 
