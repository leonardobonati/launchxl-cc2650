/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xdc_tools_configuro__
#define xdc_tools_configuro__



#endif /* xdc_tools_configuro__ */ 
