/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A46
 */

#ifndef xdc_rov_server__
#define xdc_rov_server__



#endif /* xdc_rov_server__ */ 
