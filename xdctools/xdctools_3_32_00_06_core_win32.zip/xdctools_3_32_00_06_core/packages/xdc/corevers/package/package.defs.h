/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xdc_corevers__
#define xdc_corevers__



#endif /* xdc_corevers__ */ 
